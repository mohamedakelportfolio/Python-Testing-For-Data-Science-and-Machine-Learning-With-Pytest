==================================================================================
simple_math: package do simple math operations
==================================================================================
`simple_math` is the python package to do simple math operations like addition,
subtraction and etc.
it contains 4 functions as follow ``my_add()``, ``my_sub()``,
 ``my_mult()``, ``my_divide()``
 ..code_block
    import simple_math
    n1 = 4
    n2 = 5
    simple_math.my_add(n1, n2)

    9

    that's it.
