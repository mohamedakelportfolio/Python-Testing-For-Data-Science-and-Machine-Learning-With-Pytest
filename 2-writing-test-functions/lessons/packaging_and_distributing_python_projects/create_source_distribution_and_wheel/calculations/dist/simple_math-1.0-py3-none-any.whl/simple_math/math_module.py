def my_add(a, b):
    return a + b

def my_sub(a, b):
    return a - b

def my_mult(a, b):
    return a * b

def my_divide(a, b):
    return a / b